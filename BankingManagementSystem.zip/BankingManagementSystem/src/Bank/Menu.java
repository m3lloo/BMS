
package Bank;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.DbUtils;

public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
       
        setLocationRelativeTo(null);
        TransferHistory();
    }
    
    public final void TransferHistory() {
        Login login = new Login();
        String accountNumber = Login.getUser();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");
        
        pstmt = conn.prepareStatement("SELECT Sender, Amount FROM transferhistory WHERE AccNum = ?");
        pstmt.setString(1, accountNumber);
        rs = pstmt.executeQuery();

        TransferTable.setModel(DbUtils.resultSetToTableModel(rs));
        TransferTable.getTableHeader().setReorderingAllowed(false);
        
    } catch (ClassNotFoundException | SQLException ex) {
      
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        
        try {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        LogoutButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        WelcomeLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        Services = new javax.swing.JLabel();
        Deposit = new javax.swing.JButton();
        Withdraw = new javax.swing.JButton();
        Transfer = new javax.swing.JButton();
        TransactionHistory = new javax.swing.JButton();
        AccDetails1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TransferTable = new javax.swing.JTable();
        ReceivedTransfers = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        ChangePin1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        WelcomeLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu");
        setAlwaysOnTop(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setName("Menu"); // NOI18N
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1100, 700));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(1100, 700));
        jPanel1.setLayout(null);

        LogoutButton.setBackground(new java.awt.Color(51, 51, 51));
        LogoutButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        LogoutButton.setForeground(new java.awt.Color(255, 255, 255));
        LogoutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N
        LogoutButton.setText("Logout");
        LogoutButton.setFocusable(false);
        LogoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutButtonActionPerformed(evt);
            }
        });
        jPanel1.add(LogoutButton);
        LogoutButton.setBounds(900, 640, 130, 30);

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/closeicon.png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(1030, 20, 40, 32);

        WelcomeLabel.setBackground(new java.awt.Color(0, 0, 0));
        WelcomeLabel.setFont(new java.awt.Font("Verdana", 1, 40)); // NOI18N
        WelcomeLabel.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeLabel.setText("Hello! Manage Your Finances Here");
        jPanel1.add(WelcomeLabel);
        WelcomeLabel.setBounds(170, 40, 830, 50);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));
        jPanel2.setPreferredSize(new java.awt.Dimension(1100, 700));
        jPanel2.setLayout(null);

        jPanel5.setBackground(new java.awt.Color(0, 0, 51));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, new java.awt.Color(204, 204, 204), null, new java.awt.Color(204, 204, 204)));
        jPanel5.setPreferredSize(new java.awt.Dimension(500, 500));
        jPanel5.setLayout(null);

        Services.setFont(new java.awt.Font("Verdana", 1, 50)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        jPanel5.add(Services);
        Services.setBounds(180, 20, 236, 50);

        Deposit.setBackground(new java.awt.Color(0, 0, 0));
        Deposit.setFont(new java.awt.Font("Verdana", 1, 22)); // NOI18N
        Deposit.setForeground(new java.awt.Color(255, 255, 255));
        Deposit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/deposit.png"))); // NOI18N
        Deposit.setText("Deposit");
        Deposit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        Deposit.setFocusable(false);
        Deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DepositActionPerformed(evt);
            }
        });
        jPanel5.add(Deposit);
        Deposit.setBounds(100, 160, 380, 50);

        Withdraw.setBackground(new java.awt.Color(0, 0, 0));
        Withdraw.setFont(new java.awt.Font("Verdana", 1, 22)); // NOI18N
        Withdraw.setForeground(new java.awt.Color(255, 255, 255));
        Withdraw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/withdraw.png"))); // NOI18N
        Withdraw.setText("Withdraw");
        Withdraw.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        Withdraw.setFocusable(false);
        Withdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WithdrawActionPerformed(evt);
            }
        });
        jPanel5.add(Withdraw);
        Withdraw.setBounds(100, 230, 380, 52);

        Transfer.setBackground(new java.awt.Color(0, 0, 0));
        Transfer.setFont(new java.awt.Font("Verdana", 1, 22)); // NOI18N
        Transfer.setForeground(new java.awt.Color(255, 255, 255));
        Transfer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/transfer.png"))); // NOI18N
        Transfer.setText("Transfer");
        Transfer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        Transfer.setFocusable(false);
        Transfer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransferActionPerformed(evt);
            }
        });
        jPanel5.add(Transfer);
        Transfer.setBounds(100, 300, 380, 52);

        TransactionHistory.setBackground(new java.awt.Color(0, 0, 0));
        TransactionHistory.setFont(new java.awt.Font("Verdana", 1, 22)); // NOI18N
        TransactionHistory.setForeground(new java.awt.Color(255, 255, 255));
        TransactionHistory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/transac_history.png"))); // NOI18N
        TransactionHistory.setText("Transaction History");
        TransactionHistory.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        TransactionHistory.setFocusable(false);
        TransactionHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransactionHistoryActionPerformed(evt);
            }
        });
        jPanel5.add(TransactionHistory);
        TransactionHistory.setBounds(100, 380, 380, 52);

        AccDetails1.setBackground(new java.awt.Color(0, 0, 0));
        AccDetails1.setFont(new java.awt.Font("Verdana", 1, 22)); // NOI18N
        AccDetails1.setForeground(new java.awt.Color(255, 255, 255));
        AccDetails1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/userdetails.png"))); // NOI18N
        AccDetails1.setText("Account Details");
        AccDetails1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(255, 255, 255), null, java.awt.Color.white));
        AccDetails1.setFocusPainted(false);
        AccDetails1.setFocusable(false);
        AccDetails1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccDetails1ActionPerformed(evt);
            }
        });
        jPanel5.add(AccDetails1);
        AccDetails1.setBounds(100, 90, 380, 50);

        jPanel2.add(jPanel5);
        jPanel5.setBounds(420, 20, 560, 470);

        jPanel4.setBackground(new java.awt.Color(0, 0, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        jPanel4.setLayout(null);

        jScrollPane1.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        TransferTable.setAutoCreateRowSorter(true);
        TransferTable.setBackground(new java.awt.Color(0, 0, 51));
        TransferTable.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        TransferTable.setForeground(new java.awt.Color(255, 255, 255));
        TransferTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TransferTable.setEditingColumn(0);
        TransferTable.setEditingRow(0);
        TransferTable.setEnabled(false);
        TransferTable.setFocusable(false);
        TransferTable.setRowHeight(30);
        TransferTable.setUpdateSelectionOnSort(false);
        jScrollPane1.setViewportView(TransferTable);

        jPanel4.add(jScrollPane1);
        jScrollPane1.setBounds(0, 40, 380, 380);

        ReceivedTransfers.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        ReceivedTransfers.setForeground(new java.awt.Color(255, 255, 255));
        ReceivedTransfers.setText("Received Transfers");
        jPanel4.add(ReceivedTransfers);
        ReceivedTransfers.setBounds(80, 10, 230, 26);

        jPanel2.add(jPanel4);
        jPanel4.setBounds(30, 20, 380, 420);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), java.awt.Color.white, null, java.awt.Color.white));
        jPanel3.setLayout(null);

        ChangePin1.setBackground(new java.awt.Color(0, 0, 0));
        ChangePin1.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        ChangePin1.setForeground(new java.awt.Color(255, 255, 255));
        ChangePin1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/changepin.png"))); // NOI18N
        ChangePin1.setText("Change PIN");
        ChangePin1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(255, 255, 255), null, java.awt.Color.white));
        ChangePin1.setFocusable(false);
        ChangePin1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangePin1ActionPerformed(evt);
            }
        });
        jPanel3.add(ChangePin1);
        ChangePin1.setBounds(0, 0, 380, 40);

        jPanel2.add(jPanel3);
        jPanel3.setBounds(30, 450, 380, 40);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(50, 120, 1000, 500);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(-10, 0, 1390, 770);

        WelcomeLabel1.setBackground(new java.awt.Color(0, 0, 0));
        WelcomeLabel1.setFont(new java.awt.Font("Verdana", 1, 40)); // NOI18N
        WelcomeLabel1.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeLabel1.setText("Welcome to our Bank!");
        jPanel1.add(WelcomeLabel1);
        WelcomeLabel1.setBounds(340, 0, 510, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1097, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void WithdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WithdrawActionPerformed
        Withdraw wd = new Withdraw();
        wd.setVisible(true);
        wd.setLocationRelativeTo(null);
        
    }//GEN-LAST:event_WithdrawActionPerformed
        
    private void DepositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DepositActionPerformed
        Deposit dep = new Deposit();
        dep.setVisible(true);
        dep.setLocationRelativeTo(null);
    }//GEN-LAST:event_DepositActionPerformed

    private void TransferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransferActionPerformed
        Transfer trans = new Transfer();
        trans.setVisible(true);
        trans.setLocationRelativeTo(null); 
    }//GEN-LAST:event_TransferActionPerformed

    private void TransactionHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransactionHistoryActionPerformed
         TransactionHistory th = new TransactionHistory();
         th.setVisible(true);
         th.setLocationRelativeTo(null);
    }//GEN-LAST:event_TransactionHistoryActionPerformed

    private void LogoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutButtonActionPerformed
        
    int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

    if (option == JOptionPane.YES_OPTION) {
        logout();
        }
    }//GEN-LAST:event_LogoutButtonActionPerformed

    private void AccDetails1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccDetails1ActionPerformed
        AccountDetails accdet = new AccountDetails();
        accdet.setVisible(true);
        accdet.setLocationRelativeTo(null);
    }//GEN-LAST:event_AccDetails1ActionPerformed

    private void ChangePin1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangePin1ActionPerformed
       ChangePIN change = new ChangePIN();
       change.setVisible(true);
       change.setLocationRelativeTo(null);
    }//GEN-LAST:event_ChangePin1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
        Frame[] frames = Frame.getFrames();
        for (Frame frame : frames) {
            frame.dispose();
        }
    } catch (Exception ex) {
    }
    }//GEN-LAST:event_jButton1ActionPerformed

        private void logout() {
            dispose();
    
            Login loginScreen = new Login();
            loginScreen.setVisible(true);
            loginScreen.setLocationRelativeTo(null);
        }

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AccDetails1;
    private javax.swing.JButton ChangePin1;
    private javax.swing.JButton Deposit;
    private javax.swing.JButton LogoutButton;
    private javax.swing.JLabel ReceivedTransfers;
    private javax.swing.JLabel Services;
    private javax.swing.JButton TransactionHistory;
    private javax.swing.JButton Transfer;
    private javax.swing.JTable TransferTable;
    private javax.swing.JLabel WelcomeLabel;
    private javax.swing.JLabel WelcomeLabel1;
    private javax.swing.JButton Withdraw;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
