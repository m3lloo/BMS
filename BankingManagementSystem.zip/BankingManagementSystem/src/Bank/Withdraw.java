
package Bank;

import java.sql.*;
import javax.swing.*;
import java.time.*;   

public class Withdraw extends javax.swing.JFrame {
    
    private Connection connect;
    private PreparedStatement stmt;
    private ResultSet rs;

    private PreparedStatement stAccBalance;
    private ResultSet rsAccBalance;
    
    private PreparedStatement stbd;
    private ResultSet rsbd;

    public Withdraw() {
        try {
        initComponents();
     
        connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");
        fetchBalanceDisplay();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "An error occurred during initialization: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
 
    private static String amountWithdraw;
    public static String getAmount() {
        return amountWithdraw;
    }
    private static String transactionType;
    public static String getTransactionType() {
        return transactionType;
    }
    public static LocalDateTime getCurrentDateTime() {
        return LocalDateTime.now();
    }
    public String getSelectedReason() {
        return (String) Rason.getSelectedItem();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Date = new javax.swing.JLabel();
        Reason = new javax.swing.JLabel();
        EnterAmount = new javax.swing.JLabel();
        Balance = new javax.swing.JTextField();
        DateChooser = new com.toedter.calendar.JDateChooser();
        Rason = new javax.swing.JComboBox<>();
        CurrentBalance = new javax.swing.JLabel();
        PHP = new javax.swing.JLabel();
        WithdrawAmount = new javax.swing.JTextField();
        Error = new javax.swing.JLabel();
        WithdrawLabel1 = new javax.swing.JLabel();
        ConfirmWithdrawal = new javax.swing.JButton();
        WithdrawLabel = new javax.swing.JLabel();
        Menu = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Withdraw");
        setAlwaysOnTop(true);
        setPreferredSize(new java.awt.Dimension(600, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 600));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));

        Date.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        Date.setForeground(new java.awt.Color(255, 255, 255));
        Date.setText("Transaction Date    :");

        Reason.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        Reason.setForeground(new java.awt.Color(255, 255, 255));
        Reason.setText("Use of Funds          :");

        EnterAmount.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        EnterAmount.setForeground(new java.awt.Color(255, 255, 255));
        EnterAmount.setText("Enter Amount         :");

        Balance.setEditable(false);
        Balance.setFont(new java.awt.Font("Verdana", 0, 15)); // NOI18N
        Balance.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BalanceActionPerformed(evt);
            }
        });

        DateChooser.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N

        Rason.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        Rason.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Personal reasons", "Financial constraints", "Travel plans", "Health issues", "Family emergency", "Mental health concerns", "Other  obligations" }));

        CurrentBalance.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        CurrentBalance.setForeground(new java.awt.Color(255, 255, 255));
        CurrentBalance.setText("Current balance:");

        PHP.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        PHP.setForeground(new java.awt.Color(255, 255, 255));
        PHP.setText("PHP :");

        WithdrawAmount.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
        WithdrawAmount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        WithdrawAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WithdrawAmountActionPerformed(evt);
            }
        });
        WithdrawAmount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                WithdrawAmountKeyPressed(evt);
            }
        });

        Error.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        Error.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Reason))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Rason, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(EnterAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(PHP)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Balance, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(WithdrawAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(49, 49, 49)
                    .addComponent(CurrentBalance)
                    .addContainerGap(376, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PHP)
                    .addComponent(Balance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(WithdrawAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EnterAmount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(DateChooser, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                        .addGap(45, 45, 45))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                        .addComponent(Date)
                        .addGap(60, 60, 60)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rason, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Reason))
                .addGap(185, 185, 185))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addComponent(CurrentBalance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(441, 441, 441)))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(20, 110, 560, 390);

        WithdrawLabel1.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        WithdrawLabel1.setForeground(new java.awt.Color(255, 255, 255));
        WithdrawLabel1.setText("Unlock Your Money!");
        jPanel1.add(WithdrawLabel1);
        WithdrawLabel1.setBounds(220, 70, 170, 20);

        ConfirmWithdrawal.setBackground(new java.awt.Color(51, 51, 51));
        ConfirmWithdrawal.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        ConfirmWithdrawal.setForeground(new java.awt.Color(255, 255, 255));
        ConfirmWithdrawal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/smallwithdraw.png"))); // NOI18N
        ConfirmWithdrawal.setText("Withdraw");
        ConfirmWithdrawal.setFocusable(false);
        ConfirmWithdrawal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmWithdrawalActionPerformed(evt);
            }
        });
        jPanel1.add(ConfirmWithdrawal);
        ConfirmWithdrawal.setBounds(220, 510, 140, 31);

        WithdrawLabel.setFont(new java.awt.Font("Verdana", 1, 45)); // NOI18N
        WithdrawLabel.setForeground(new java.awt.Color(255, 255, 255));
        WithdrawLabel.setText("Withdraw");
        jPanel1.add(WithdrawLabel);
        WithdrawLabel.setBounds(170, 10, 260, 56);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(30, 30, 110, 31);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(-3, -30, 620, 1140);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 240, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BalanceActionPerformed
    fetchBalanceDisplay();
    }//GEN-LAST:event_BalanceActionPerformed
        
    private void fetchBalanceDisplay() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT Amount FROM signup WHERE AccNum = ?"; 
        stbd = connect.prepareStatement(query);
        stbd.setString(1, accountNumber);
        rsbd = stbd.executeQuery();

        if (rsbd.next()) {
            int balance = rsbd.getInt("Amount");
            Balance.setText(Integer.toString(balance)); 
        } else {
            Balance.setText("0");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching account balance: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stbd != null) {
                stbd.close();
            }
            if (rsbd != null) {
                rsbd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    
    private static boolean withdrawbutton = false;
    private void ConfirmWithdrawalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmWithdrawalActionPerformed
    withdrawbutton = true;
    Login login = new Login();
    String accountNumber = Login.getUser();

    amountWithdraw = WithdrawAmount.getText();
    int amountInt = Integer.parseInt(amountWithdraw);
    transactionType = "Withdraw";
    LocalDateTime currentDateTime = LocalDateTime.now();

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");

        PreparedStatement checkAccountPstmt = conn.prepareStatement("SELECT Amount FROM signup WHERE AccNum = ?");
        checkAccountPstmt.setString(1, accountNumber);
        ResultSet accountResult = checkAccountPstmt.executeQuery();

        if (!accountResult.next()) {
            JOptionPane.showMessageDialog(this, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int currentBalance = accountResult.getInt("Amount");
        accountResult.close();
        checkAccountPstmt.close();

        if (amountInt > currentBalance) {
            JOptionPane.showMessageDialog(this, "Insufficient balance to withdraw", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int newBalance = currentBalance - amountInt;

        PreparedStatement updateBalancePstmt = conn.prepareStatement("UPDATE signup SET Amount = ? WHERE AccNum = ?");
        updateBalancePstmt.setInt(1, newBalance);
        updateBalancePstmt.setString(2, accountNumber);
        updateBalancePstmt.executeUpdate();
        updateBalancePstmt.close();

        PreparedStatement insertRecordPstmt = conn.prepareStatement("INSERT INTO records (AccNum, Amount, Date, Time, Type, Reason) VALUES (?, ?, ?, ?, ?, ?)");
        insertRecordPstmt.setString(1, accountNumber);
        insertRecordPstmt.setInt(2, amountInt);
        insertRecordPstmt.setDate(3, java.sql.Date.valueOf(currentDateTime.toLocalDate()));
        insertRecordPstmt.setTime(4, java.sql.Time.valueOf(currentDateTime.toLocalTime()));
        insertRecordPstmt.setString(5, "Withdraw");
        insertRecordPstmt.setString(6, (String) Rason.getSelectedItem());
        insertRecordPstmt.executeUpdate();
        insertRecordPstmt.close();

        
        int option = JOptionPane.showConfirmDialog(this, "Withdraw Successfully.\n\nDo you want to print the receipt?", "Print Receipt", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            dispose();
             Receipt receiptFrame = new Receipt();
              receiptFrame.setVisible(true);
        } else {
         int choice = JOptionPane.showConfirmDialog(this, "Do you want to execute another withdrawal?", "Confirmation", JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            refreshFrame();
        } else {
            dispose();
        }
}
       

        conn.close();

    } catch (SQLException | ClassNotFoundException ex) {
        JOptionPane.showMessageDialog(this, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_ConfirmWithdrawalActionPerformed

        public static boolean WithdrawClicked() {
        return withdrawbutton;
    }
    
    private void refreshFrame() {
    dispose();

    Withdraw frame = new Withdraw(); 
    frame.setVisible(true);
    frame.BalanceActionPerformed(null);
    frame.setLocationRelativeTo(null);
}
    
    private void WithdrawAmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WithdrawAmountActionPerformed
       
    }//GEN-LAST:event_WithdrawAmountActionPerformed

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

    private void WithdrawAmountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_WithdrawAmountKeyPressed
       char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            WithdrawAmount.setEditable(false);
            Error.setText("Please enter a valid amount value.");
        } else {
            WithdrawAmount.setEditable(true);
            Error.setText("");
        }
    }//GEN-LAST:event_WithdrawAmountKeyPressed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> {
            new Withdraw().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Balance;
    private javax.swing.JButton ConfirmWithdrawal;
    private javax.swing.JLabel CurrentBalance;
    private javax.swing.JLabel Date;
    private com.toedter.calendar.JDateChooser DateChooser;
    private javax.swing.JLabel EnterAmount;
    private javax.swing.JLabel Error;
    private javax.swing.JButton Menu;
    private javax.swing.JLabel PHP;
    private javax.swing.JComboBox<String> Rason;
    private javax.swing.JLabel Reason;
    private javax.swing.JTextField WithdrawAmount;
    private javax.swing.JLabel WithdrawLabel;
    private javax.swing.JLabel WithdrawLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
