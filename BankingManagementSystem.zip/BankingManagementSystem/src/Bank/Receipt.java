

package Bank;


import java.time.LocalDateTime;

public class Receipt extends javax.swing.JFrame {
    
   
   
    
    public Receipt() {
         initComponents();
         initializeReceipt();
         setLocationRelativeTo(null);
    }

    private void initializeReceipt() {
    if(Deposit.DepositClicked()) {
        displayDepositReceipt(); 
    } else if (Withdraw.WithdrawClicked()) {
        displayWithdrawReceipt(); 
    } else if (Transfer.TransferClicked()){
        displayTransferReceipt();
    }
}

    
    private void displayDepositReceipt() {
    String accountNumber = Login.getUser();
    var amount = Deposit.getAmountDeposit();
    String transactionType = Deposit.getTransactionTypeDeposit();
    LocalDateTime currentDateTime = LocalDateTime.now();
    Deposit deposit = new Deposit();
    String reason = deposit.getSelectedReasonDeposit();

    Rec.setText("**************************************\n");
    Rec.append("*****               Deposit Receipt                *****\n");
    Rec.append("**************************************\n");
    Rec.append("\n");
    Rec.append("\n Account Number        : " + accountNumber);
    Rec.append("\n Transaction Amount : PHP " + amount);
    Rec.append("\n Transaction Type      : " + transactionType);
    Rec.append("\n Transaction Date      : " + currentDateTime.toLocalDate());
    Rec.append("\n Transaction Time      : " + currentDateTime.toLocalTime());
    Rec.append("\n Description                 : " + reason);
    Rec.append("\n--------------------------------------------------\n");
    Rec.append("\n");
    Rec.append("            Thank you for banking with us.\n");
    Rec.append("   Please keep this receipt for your records.");
}
    
    private void displayTransferReceipt() {
    String senderAccountNumber = Login.getUser();
    String receiverAccountNumber = Transfer.getReceiver();
    var amount = Transfer.getAmountTransfer();
    String transactionType = Transfer.getTransactionTypeTransfer();
    LocalDateTime currentDateTime = LocalDateTime.now();
    Transfer transfer = new Transfer();
    String reason = transfer.getSelectedReasonTransfer();

    Rec.setText("**************************************\n");
    Rec.append("*****              Transfer Receipt                *****\n");
    Rec.append("**************************************\n");
    Rec.append("\n");
    Rec.append("\n Sender Account Number    : " + senderAccountNumber);
    Rec.append("\n Receiver Account Number : " + receiverAccountNumber);
    Rec.append("\n Transaction Amount : PHP " + amount);
    Rec.append("\n Transaction Type      : " + transactionType);
    Rec.append("\n Transaction Date      : " + currentDateTime.toLocalDate());
    Rec.append("\n Transaction Time      : " + currentDateTime.toLocalTime());
    Rec.append("\n Description                 : " + reason);
    Rec.append("\n--------------------------------------------------\n");
    Rec.append("\n");
    Rec.append("            Thank you for banking with us.\n");
    Rec.append("   Please keep this receipt for your records.");
}


    private void displayWithdrawReceipt() {
    Login login = new Login();
    String accountNumber = Login.getUser();
    
    Withdraw withdrawalFrame = new Withdraw();
    
    var amount = Withdraw.getAmount();
    var transactionType = Withdraw.getTransactionType();
    LocalDateTime currentDateTime = Withdraw.getCurrentDateTime();
    String reason = withdrawalFrame.getSelectedReason();


    Rec.setText("**************************************\n");
    Rec.append("*****             Withdrawal Receipt           *****\n");
    Rec.append("**************************************\n");
    Rec.append("\n");
    Rec.append("\n Account Number        : " + accountNumber);
    Rec.append("\n Transaction Amount : PHP " + amount);
    Rec.append("\n Transaction Type      : " + transactionType);
    Rec.append("\n Transaction Date      : " + currentDateTime.toLocalDate());
    Rec.append("\n Transaction Time      : " + currentDateTime.toLocalTime());
    Rec.append("\n Description                 : " + reason);
    Rec.append("\n--------------------------------------------------\n");
    Rec.append("\n");
    Rec.append("            Thank you for banking with us.\n");
    Rec.append("   Please keep this receipt for your records.");
}

        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Rec = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        Menu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(400, 500));
        setResizable(false);
        setSize(new java.awt.Dimension(400, 400));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(400, 500));
        jPanel1.setLayout(null);

        Rec.setEditable(false);
        Rec.setBackground(new java.awt.Color(255, 255, 255));
        Rec.setColumns(20);
        Rec.setFont(new java.awt.Font("Verdana", 1, 16)); // NOI18N
        Rec.setRows(5);
        Rec.setAutoscrolls(false);
        Rec.setBorder(null);
        Rec.setMargin(new java.awt.Insets(0, 0, 0, 0));
        Rec.setMinimumSize(new java.awt.Dimension(0, 0));
        Rec.setPreferredSize(new java.awt.Dimension(400, 500));
        jPanel1.add(Rec);
        Rec.setBounds(0, 10, 400, 390);

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(null);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Close");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.setMargin(new java.awt.Insets(0, 0, 0, 0));
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel2.add(Menu);
        Menu.setBounds(130, 30, 120, 40);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 410, 400, 90);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new Receipt().setVisible(true);   
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Menu;
    private javax.swing.JTextArea Rec;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
