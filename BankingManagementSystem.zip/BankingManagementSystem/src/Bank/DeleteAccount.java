package Bank;

import java.awt.*;
import javax.swing.*;
import java.sql.*;

public class DeleteAccount extends javax.swing.JFrame {

    
    
    public DeleteAccount() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        EnterPINLabel = new javax.swing.JLabel();
        PIN = new javax.swing.JPasswordField();
        Error = new javax.swing.JLabel();
        Menu = new javax.swing.JButton();
        DeleteLabel1 = new javax.swing.JLabel();
        DeleteAccount = new javax.swing.JButton();
        DeleteLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Delete Account");
        setAlwaysOnTop(true);
        setName("Delete Account"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(400, 400));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));

        EnterPINLabel.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        EnterPINLabel.setForeground(new java.awt.Color(255, 255, 255));
        EnterPINLabel.setText("Enter your PIN:");

        PIN.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        PIN.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PIN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PINKeyPressed(evt);
            }
        });

        Error.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        Error.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(PIN, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(EnterPINLabel)
                        .addGap(88, 88, 88))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(EnterPINLabel)
                .addGap(18, 18, 18)
                .addComponent(PIN, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(30, 190, 340, 130);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(30, 20, 120, 31);

        DeleteLabel1.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        DeleteLabel1.setForeground(new java.awt.Color(255, 255, 255));
        DeleteLabel1.setText("End Your Relationship with Us? :(");
        jPanel1.add(DeleteLabel1);
        DeleteLabel1.setBounds(70, 140, 280, 30);

        DeleteAccount.setBackground(new java.awt.Color(255, 0, 0));
        DeleteAccount.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        DeleteAccount.setText("Delete");
        DeleteAccount.setFocusable(false);
        DeleteAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAccountActionPerformed(evt);
            }
        });
        jPanel1.add(DeleteAccount);
        DeleteAccount.setBounds(140, 340, 110, 27);

        DeleteLabel.setFont(new java.awt.Font("Verdana", 1, 38)); // NOI18N
        DeleteLabel.setForeground(new java.awt.Color(255, 255, 255));
        DeleteLabel.setText("Delete Account");
        jPanel1.add(DeleteLabel);
        DeleteLabel.setBounds(40, 90, 330, 47);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -10, 420, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeleteAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAccountActionPerformed
       String enteredPin = PIN.getText();

    Login login = new Login();
    String accountNumber = Login.getUser();

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");

        String selectQuery = "SELECT PINPass FROM signup WHERE AccNum = ?";
        PreparedStatement selectStmt = con.prepareStatement(selectQuery);
        selectStmt.setString(1, accountNumber);
        ResultSet rs = selectStmt.executeQuery();

        if (rs.next()) {
            String pinFromDatabase = rs.getString("PINPass");

            if (enteredPin.equals(pinFromDatabase)) {
                String selectBalanceQuery = "SELECT Amount FROM signup WHERE AccNum = ?";
                PreparedStatement selectBalanceStmt = con.prepareStatement(selectBalanceQuery);
                selectBalanceStmt.setString(1, accountNumber);
                ResultSet rsBalance = selectBalanceStmt.executeQuery();

                if (rsBalance.next()) {
                    double balance = rsBalance.getDouble("Amount");

                    if (balance > 0) {
                        String[] options = {"Withdraw the amount", "Donate to charity"};
                        int choice = JOptionPane.showOptionDialog(this,
                                "You still have a balance of $" + balance + " in your account. What do you want to do with it?",
                                "Balance Exists",
                                JOptionPane.DEFAULT_OPTION,
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                options,
                                options[0]);

                        if (choice == 0) { 
                            JOptionPane.showMessageDialog(this, "You have withdrawn your remaining balance successfully before account deletion.", "Balance Withdrawn", JOptionPane.INFORMATION_MESSAGE);
                        } else if (choice == 1) {
                            JOptionPane.showMessageDialog(this, "Thank you for donating your remaining balance to charity!", "Balance Donated", JOptionPane.INFORMATION_MESSAGE);
                            // Handle donation logic here if needed
                        }
                    }

                    // Proceed with account deletion
                    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        try {
                            String deleteSignupQuery = "DELETE FROM signup WHERE AccNum = ?";
                            PreparedStatement deleteSignupStmt = con.prepareStatement(deleteSignupQuery);
                            deleteSignupStmt.setString(1, accountNumber);
                            deleteSignupStmt.executeUpdate();

                            String deleteRecordsQuery = "DELETE FROM records WHERE AccNum = ?";
                            PreparedStatement deleteRecordsStmt = con.prepareStatement(deleteRecordsQuery);
                            deleteRecordsStmt.setString(1, accountNumber);
                            deleteRecordsStmt.executeUpdate();

                            String deleteTHQuery = "DELETE FROM transferhistory WHERE Sender = ?";
                            PreparedStatement deleteTHStmt = con.prepareStatement(deleteTHQuery);
                            deleteTHStmt.setString(1, accountNumber);
                            deleteTHStmt.executeUpdate();

                            for (Window window : Window.getWindows()) {
                                window.dispose();
                            }

                            login.setVisible(true);
                            login.setLocationRelativeTo(null);
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(this, "Error deleting account: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Account balance not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect PIN. Deletion aborted.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (ClassNotFoundException | SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error accessing database: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_DeleteAccountActionPerformed

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

    private void PINKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PINKeyPressed
       char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            PIN.setEditable(false);
            Error.setText("Must be digits!");
        } else {
            PIN.setEditable(true);
            Error.setText("");
        }
    }//GEN-LAST:event_PINKeyPressed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new DeleteAccount().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteAccount;
    private javax.swing.JLabel DeleteLabel;
    private javax.swing.JLabel DeleteLabel1;
    private javax.swing.JLabel EnterPINLabel;
    private javax.swing.JLabel Error;
    private javax.swing.JButton Menu;
    private javax.swing.JPasswordField PIN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}


