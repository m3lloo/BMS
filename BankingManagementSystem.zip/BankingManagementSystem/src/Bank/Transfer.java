package Bank;

import java.sql.*;
import javax.swing.*;
import java.time.*;


public class Transfer extends javax.swing.JFrame {

    private Connection conn;
    
 
    public Transfer() {
        initComponents();
        connectToDatabase();
    }
    
    private void connectToDatabase(){
        try {
            
            String url = "jdbc:mysql://localhost:3306/bankingsystem";
            String username = "root";
            String password = "";
            
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private static String TransferAmountToReturn;
    public static String getAmountTransfer() {
        return TransferAmountToReturn;
    }
    
    public String getSelectedReasonTransfer() {
        return (String) Reason.getSelectedItem();
    }
    
    private static String transactionType;
    public static String getTransactionTypeTransfer() {
        return transactionType;
    }
    
    private static String receiverAccountNumber;
    public static String getReceiver() {
        return receiverAccountNumber;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        TransferButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        ReceiversAccNum = new javax.swing.JLabel();
        Receiver = new javax.swing.JTextField();
        EnterAmount = new javax.swing.JLabel();
        TransferAmount = new javax.swing.JTextField();
        Description = new javax.swing.JLabel();
        Reason = new javax.swing.JComboBox<>();
        Error = new javax.swing.JLabel();
        Error1 = new javax.swing.JLabel();
        TransferLabel = new javax.swing.JLabel();
        Menu = new javax.swing.JButton();
        TransferLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(true);
        setPreferredSize(new java.awt.Dimension(600, 600));

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 650));
        jPanel1.setLayout(null);

        TransferButton.setBackground(new java.awt.Color(51, 51, 51));
        TransferButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        TransferButton.setForeground(new java.awt.Color(255, 255, 255));
        TransferButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/smalltransfer.png"))); // NOI18N
        TransferButton.setText("Transfer");
        TransferButton.setFocusable(false);
        TransferButton.setOpaque(true);
        TransferButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransferButtonActionPerformed(evt);
            }
        });
        jPanel1.add(TransferButton);
        TransferButton.setBounds(220, 500, 140, 31);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));
        jPanel2.setPreferredSize(new java.awt.Dimension(600, 650));

        ReceiversAccNum.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        ReceiversAccNum.setForeground(new java.awt.Color(255, 255, 255));
        ReceiversAccNum.setText("Receiver's Account No.  :");

        Receiver.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
        Receiver.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Receiver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReceiverActionPerformed(evt);
            }
        });
        Receiver.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ReceiverKeyPressed(evt);
            }
        });

        EnterAmount.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        EnterAmount.setForeground(new java.awt.Color(255, 255, 255));
        EnterAmount.setText("Enter amount          :");

        TransferAmount.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
        TransferAmount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TransferAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransferAmountActionPerformed(evt);
            }
        });
        TransferAmount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TransferAmountKeyPressed(evt);
            }
        });

        Description.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        Description.setForeground(new java.awt.Color(255, 255, 255));
        Description.setText("Transfer Reason      :");

        Reason.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        Reason.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bill Payment", "Loan Repayment", "Purchase", "Transfer to Another Account", "Gift or Donation" }));

        Error.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        Error.setForeground(new java.awt.Color(255, 255, 255));

        Error1.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        Error1.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 38, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Description, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Reason, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(EnterAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TransferAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(ReceiversAccNum)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Error1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Receiver, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(28, 28, 28))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EnterAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TransferAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Description, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Reason, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ReceiversAccNum, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Receiver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Error1, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(73, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 120, 560, 370);

        TransferLabel.setFont(new java.awt.Font("Verdana", 1, 45)); // NOI18N
        TransferLabel.setForeground(new java.awt.Color(255, 255, 255));
        TransferLabel.setText("Transfer");
        jPanel1.add(TransferLabel);
        TransferLabel.setBounds(190, 20, 220, 50);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(20, 30, 110, 31);

        TransferLabel1.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        TransferLabel1.setForeground(new java.awt.Color(255, 255, 255));
        TransferLabel1.setText("Send Your Funds!");
        jPanel1.add(TransferLabel1);
        TransferLabel1.setBounds(220, 80, 150, 20);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(-3, -50, 660, 1170);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 562, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 88, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

    private void ReceiverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReceiverActionPerformed
       
    }//GEN-LAST:event_ReceiverActionPerformed

    private void TransferAmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransferAmountActionPerformed
        
    }//GEN-LAST:event_TransferAmountActionPerformed

     private static boolean transferbutton = false;
    private void TransferButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransferButtonActionPerformed
        transferbutton = true; 
        Login login = new Login();
        String accountNumber = Login.getUser();
        transactionType = "Transfer";     
        receiverAccountNumber = Receiver.getText();
        TransferAmountToReturn = TransferAmount.getText();
        int amount = Integer.parseInt(TransferAmountToReturn);
        String reason = (String) Reason.getSelectedItem();

try {

    if (TransferAmountToReturn.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the transfer amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
    if (receiverAccountNumber.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please input the account number of the receiver.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    PreparedStatement checkReceiverPstmt = conn.prepareStatement("SELECT AccNum FROM signup WHERE AccNum = ?");
    checkReceiverPstmt.setString(1, receiverAccountNumber);
    ResultSet receiverResult = checkReceiverPstmt.executeQuery();

    if (!receiverResult.next()) {
        JOptionPane.showMessageDialog(this, "Receiver account not found.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    PreparedStatement checkSenderPstmt = conn.prepareStatement("SELECT Amount FROM signup WHERE AccNum = ?");
    checkSenderPstmt.setString(1, accountNumber);
    ResultSet senderResult = checkSenderPstmt.executeQuery();

    if (senderResult.next()) {
        int senderBalance = senderResult.getInt("Amount");

        if (amount > senderBalance) {
            JOptionPane.showMessageDialog(this, "Insufficient balance to transfer", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        PreparedStatement updateSenderBalancePstmt = conn.prepareStatement("UPDATE signup SET Amount = Amount - ? WHERE AccNum = ?");
        updateSenderBalancePstmt.setInt(1, amount);
        updateSenderBalancePstmt.setString(2, accountNumber);
        updateSenderBalancePstmt.executeUpdate();
        updateSenderBalancePstmt.close();

        PreparedStatement updateReceiverBalancePstmt = conn.prepareStatement("UPDATE signup SET Amount = Amount + ? WHERE AccNum = ?");
        updateReceiverBalancePstmt.setInt(1, amount);
        updateReceiverBalancePstmt.setString(2, receiverAccountNumber);
        updateReceiverBalancePstmt.executeUpdate();
        updateReceiverBalancePstmt.close();

        PreparedStatement insertRecordPstmt = conn.prepareStatement("INSERT INTO records (AccNum, Amount, Date, Time, Type, Reason) VALUES (?, ?, ?, ?, ?, ?)");
        insertRecordPstmt.setString(1, accountNumber);
        insertRecordPstmt.setInt(2, amount);
        insertRecordPstmt.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
        insertRecordPstmt.setTime(4, java.sql.Time.valueOf(LocalTime.now()));
        insertRecordPstmt.setString(5, transactionType);
        insertRecordPstmt.setString(6, reason);
        insertRecordPstmt.executeUpdate();
        insertRecordPstmt.close();

        PreparedStatement insertTransferPstmt = conn.prepareStatement("INSERT INTO transferhistory (Sender, AccNum, Amount, Date, Time) VALUES (?, ?, ?, ?, ?)");
        insertTransferPstmt.setString(1, accountNumber);
        insertTransferPstmt.setString(2, receiverAccountNumber);
        insertTransferPstmt.setInt(3, amount);
        insertTransferPstmt.setDate(4, java.sql.Date.valueOf(LocalDate.now()));
        insertTransferPstmt.setTime(5, java.sql.Time.valueOf(LocalTime.now()));
        insertTransferPstmt.executeUpdate();
        insertTransferPstmt.close();

        int option = JOptionPane.showConfirmDialog(this, "Transfer Successfully.\n\nDo you want to print the receipt?", "Print Receipt", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            Receipt receiptFrame = new Receipt();
            receiptFrame.setVisible(true);
            dispose();
        } else {
            dispose();
        }
    } else {
        JOptionPane.showMessageDialog(this, "Sender account not found.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    conn.close();

} catch (SQLException ex) {
    JOptionPane.showMessageDialog(this, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}

    }//GEN-LAST:event_TransferButtonActionPerformed

    private void TransferAmountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TransferAmountKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            TransferAmount.setEditable(false);
            Error.setText("Please enter a valid amount value.");
        } else {
            TransferAmount.setEditable(true);
            Error.setText("");
        }
    }//GEN-LAST:event_TransferAmountKeyPressed

    private void ReceiverKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ReceiverKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            Receiver.setEditable(false);
            Error1.setText("Must be digits only!");
        } else {
            Receiver.setEditable(true);
            Error1.setText("");
        }
    }//GEN-LAST:event_ReceiverKeyPressed
    
    public static boolean TransferClicked() {
        return transferbutton;
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new Transfer().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Description;
    private javax.swing.JLabel EnterAmount;
    private javax.swing.JLabel Error;
    private javax.swing.JLabel Error1;
    private javax.swing.JButton Menu;
    private javax.swing.JComboBox<String> Reason;
    private javax.swing.JTextField Receiver;
    private javax.swing.JLabel ReceiversAccNum;
    private javax.swing.JTextField TransferAmount;
    private javax.swing.JButton TransferButton;
    private javax.swing.JLabel TransferLabel;
    private javax.swing.JLabel TransferLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
