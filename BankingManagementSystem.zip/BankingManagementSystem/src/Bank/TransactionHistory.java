package Bank;

import javax.swing.*;
import net.proteanit.sql.DbUtils;
import java.sql.*;
import javax.swing.table.*;

public class TransactionHistory extends javax.swing.JFrame {
    
    public TransactionHistory() {
        initComponents();
        pack();
        History();
    }
 
    public final void History() {
        
        Login login = new Login();
        String accountNumber = Login.getUser();
        Connection conn = null;
        PreparedStatement AccChecker = null;
        ResultSet res = null;
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");
        
        AccChecker = conn.prepareStatement("SELECT ReferenceID, Amount, Date, Time, Type, Reason FROM records WHERE AccNum = ?");
        AccChecker.setString(1, accountNumber);
        res = AccChecker.executeQuery();
        
        HistoryTable.setModel(DbUtils.resultSetToTableModel(res));
        HistoryTable.getTableHeader().setReorderingAllowed(false);
    } catch (ClassNotFoundException | SQLException ex) {
        JOptionPane.showMessageDialog(this, "An error occurred while fetching data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (res != null) {
                res.close();
            }
            if (AccChecker != null) {
                AccChecker.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while closing resources: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SearchComboBox = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        HistoryTable = new javax.swing.JTable();
        Menu = new javax.swing.JButton();
        Transaction1 = new javax.swing.JLabel();
        Transaction = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Transaction History");
        setAlwaysOnTop(true);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 1366, 768));
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(901, 700));
        jPanel1.setLayout(null);

        SearchComboBox.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        SearchComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All transactions", "Deposit", "Withdraw", "Transfer" }));
        SearchComboBox.setFocusable(false);
        SearchComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchComboBoxActionPerformed(evt);
            }
        });
        jPanel1.add(SearchComboBox);
        SearchComboBox.setBounds(610, 130, 250, 26);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));

        HistoryTable.setAutoCreateRowSorter(true);
        HistoryTable.setBackground(new java.awt.Color(0, 0, 51));
        HistoryTable.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        HistoryTable.setForeground(new java.awt.Color(255, 255, 255));
        HistoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        HistoryTable.setEnabled(false);
        jScrollPane1.setViewportView(HistoryTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 848, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 170, 860, 500);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(20, 30, 120, 31);

        Transaction1.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Transaction1.setForeground(new java.awt.Color(255, 255, 255));
        Transaction1.setText("Explore Your Financial Activity");
        jPanel1.add(Transaction1);
        Transaction1.setBounds(320, 90, 250, 20);

        Transaction.setFont(new java.awt.Font("Verdana", 1, 45)); // NOI18N
        Transaction.setForeground(new java.awt.Color(255, 255, 255));
        Transaction.setText("Transaction History");
        jPanel1.add(Transaction);
        Transaction.setBounds(190, 30, 530, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(-3, -20, 880, 1120);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 887, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

    private void SearchComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchComboBoxActionPerformed
       String selectedType = (String) SearchComboBox.getSelectedItem();
    
    
    DefaultTableModel model = (DefaultTableModel) HistoryTable.getModel();
    
   
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    HistoryTable.setRowSorter(sorter);
    
    
    int transactionTypeColumnIndex = -1;
    for (int i = 0; i < model.getColumnCount(); i++) {
        if (model.getColumnName(i).equals("Type")) {
            transactionTypeColumnIndex = i;
            break;
        }
    }
    
    RowFilter<Object, Object> rowFilter = null;

    if (!selectedType.equals("All transactions")) {

        if (selectedType.equals("Deposit") || selectedType.equals("Withdraw") || selectedType.equals("Transfer")) {
            rowFilter = RowFilter.regexFilter(selectedType, transactionTypeColumnIndex);
        }
    }

    sorter.setRowFilter(rowFilter);
    }//GEN-LAST:event_SearchComboBoxActionPerformed

 
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> {
            new TransactionHistory().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable HistoryTable;
    private javax.swing.JButton Menu;
    private javax.swing.JComboBox<String> SearchComboBox;
    private javax.swing.JLabel Transaction;
    private javax.swing.JLabel Transaction1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
