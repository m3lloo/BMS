
package Bank;


import java.sql.*;
import javax.swing.*;
import java.time.*;

public class Deposit extends javax.swing.JFrame {

    public Deposit() {
        initComponents(); 
        setLocationRelativeTo(null);
    }
    
    private static String amount;
    public static String getAmountDeposit() {
        return amount;
    }
    private static String transactionType;
    public static String getTransactionTypeDeposit() {
        return transactionType;
    }
    public static LocalDateTime getCurrentDateTimeDeposit() {
        return LocalDateTime.now();
    }
    private String Reason;
    public String getSelectedReasonDeposit() {
        return (String) Rason.getSelectedItem();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        DateLabel = new javax.swing.JLabel();
        Description = new javax.swing.JLabel();
        EnterAmount = new javax.swing.JLabel();
        AmountDeposit = new javax.swing.JTextField();
        Date = new com.toedter.calendar.JDateChooser();
        Rason = new javax.swing.JComboBox<>();
        ErrorDeposit = new javax.swing.JLabel();
        DepositLabel = new javax.swing.JLabel();
        DepositLabel1 = new javax.swing.JLabel();
        ConfirmDeposit = new javax.swing.JButton();
        Menu = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Deposit");
        setAlwaysOnTop(true);
        setName("Deposit"); // NOI18N
        setPreferredSize(new java.awt.Dimension(600, 600));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setMinimumSize(new java.awt.Dimension(1366, 768));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 600));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));
        jPanel2.setPreferredSize(new java.awt.Dimension(600, 502));

        DateLabel.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        DateLabel.setForeground(new java.awt.Color(255, 255, 255));
        DateLabel.setText("Transaction Date    :");

        Description.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        Description.setForeground(new java.awt.Color(255, 255, 255));
        Description.setText("Description            :");

        EnterAmount.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        EnterAmount.setForeground(new java.awt.Color(255, 255, 255));
        EnterAmount.setText("Enter Amount         :");

        AmountDeposit.setFont(new java.awt.Font("Verdana", 0, 22)); // NOI18N
        AmountDeposit.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        AmountDeposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AmountDepositActionPerformed(evt);
            }
        });
        AmountDeposit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AmountDepositKeyPressed(evt);
            }
        });

        Date.setDateFormatString("Month, Day, Year");
        Date.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N

        Rason.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Rason.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Savings Deposit", "Bill Payment", "Investment Deposit", "Salary Deposit", "Purchase Payment", " " }));

        ErrorDeposit.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorDeposit.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ErrorDeposit, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(EnterAmount)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(AmountDeposit, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(Description)
                            .addGap(18, 18, 18)
                            .addComponent(Rason, 0, 1, Short.MAX_VALUE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(DateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AmountDeposit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EnterAmount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ErrorDeposit, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Date, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                        .addGap(290, 290, 290))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(DateLabel)
                        .addGap(57, 57, 57)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Description)
                            .addComponent(Rason, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(205, Short.MAX_VALUE))))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(40, 130, 530, 330);

        DepositLabel.setFont(new java.awt.Font("Verdana", 1, 45)); // NOI18N
        DepositLabel.setForeground(new java.awt.Color(255, 255, 255));
        DepositLabel.setText("Deposit");
        jPanel1.add(DepositLabel);
        DepositLabel.setBounds(200, 30, 200, 56);

        DepositLabel1.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        DepositLabel1.setForeground(new java.awt.Color(255, 255, 255));
        DepositLabel1.setText("Increase Your Wealth");
        jPanel1.add(DepositLabel1);
        DepositLabel1.setBounds(210, 90, 180, 20);

        ConfirmDeposit.setBackground(new java.awt.Color(51, 51, 51));
        ConfirmDeposit.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        ConfirmDeposit.setForeground(new java.awt.Color(255, 255, 255));
        ConfirmDeposit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/smalldeposit.png"))); // NOI18N
        ConfirmDeposit.setText("Deposit");
        ConfirmDeposit.setFocusable(false);
        ConfirmDeposit.setOpaque(true);
        ConfirmDeposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmDepositActionPerformed(evt);
            }
        });
        jPanel1.add(ConfirmDeposit);
        ConfirmDeposit.setBounds(230, 480, 130, 31);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(30, 30, 110, 31);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel6.setText("jLabel6");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, -40, 610, 1160);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 49, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed
        
    private static boolean depositbutton = false;
    private void ConfirmDepositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmDepositActionPerformed
        depositbutton = true;
        Login login = new Login();
        String accountNumber = Login.getUser();

        amount = AmountDeposit.getText();
        int amountInt = Integer.parseInt(amount);

        transactionType = "Deposit";
        LocalDateTime currentDateTime = LocalDateTime.now();

        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");

            PreparedStatement checkAccountPstmt = conn.prepareStatement("SELECT Amount FROM signup WHERE AccNum = ?");
            checkAccountPstmt.setString(1, accountNumber);
            ResultSet accountResult = checkAccountPstmt.executeQuery();

            if (!accountResult.next()) {
                JOptionPane.showMessageDialog(this, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int currentBalance = accountResult.getInt("Amount");
            accountResult.close();
            checkAccountPstmt.close();

            int newBalance = currentBalance + amountInt;

            PreparedStatement updateBalancePstmt = conn.prepareStatement("UPDATE signup SET Amount = ? WHERE AccNum = ?");
            updateBalancePstmt.setInt(1, newBalance);
            updateBalancePstmt.setString(2, accountNumber);
            updateBalancePstmt.executeUpdate();
            updateBalancePstmt.close();

            PreparedStatement insertRecordPstmt = conn.prepareStatement("INSERT INTO records (AccNum, Amount, Date, Time, Type, Reason) VALUES (?, ?, ?, ?, ?, ?)");
            insertRecordPstmt.setString(1, accountNumber);
            insertRecordPstmt.setString(2, amount);
            insertRecordPstmt.setDate(3, java.sql.Date.valueOf(currentDateTime.toLocalDate())); 
            insertRecordPstmt.setTime(4, java.sql.Time.valueOf(currentDateTime.toLocalTime())); 
            insertRecordPstmt.setString(5, "Deposit");
            insertRecordPstmt.setString(6, (String) Rason.getSelectedItem());
            insertRecordPstmt.executeUpdate();
            insertRecordPstmt.close();

            int option = JOptionPane.showConfirmDialog(this, "Deposit Successfully.\n\nDo you want to print the receipt?", "Print Receipt", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
             Receipt receiptFrame = new Receipt();
              receiptFrame.setVisible(true);
              dispose();
        } else {
       dispose();
}

            conn.close();
        } catch (SQLException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_ConfirmDepositActionPerformed

    public static boolean DepositClicked() {
        return depositbutton;
    }
    
    private void AmountDepositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AmountDepositActionPerformed
        
    }//GEN-LAST:event_AmountDepositActionPerformed

    private void AmountDepositKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AmountDepositKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            AmountDeposit.setEditable(false);
            ErrorDeposit.setText("Please enter a valid amount value.");
        } else {
            AmountDeposit.setEditable(true);
            ErrorDeposit.setText("");
        }
    }//GEN-LAST:event_AmountDepositKeyPressed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> {
            new Deposit().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AmountDeposit;
    private javax.swing.JButton ConfirmDeposit;
    private com.toedter.calendar.JDateChooser Date;
    private javax.swing.JLabel DateLabel;
    private javax.swing.JLabel DepositLabel;
    private javax.swing.JLabel DepositLabel1;
    private javax.swing.JLabel Description;
    private javax.swing.JLabel EnterAmount;
    private javax.swing.JLabel ErrorDeposit;
    private javax.swing.JButton Menu;
    private javax.swing.JComboBox<String> Rason;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
