
package Bank;

import java.sql.*;
import javax.swing.*;
import java.time.*;

public class AccountDetails extends javax.swing.JFrame {

    private Connection connector;
    private PreparedStatement st;
    private ResultSet rs;
    
    private PreparedStatement stname;
    private ResultSet rsname;
    
    private PreparedStatement stPhone;
    private ResultSet rsPhone;
    
    private PreparedStatement stGender;
    private ResultSet rsGender;
    
    private PreparedStatement stAdd;
    private ResultSet rsAdd;
    
    private PreparedStatement stAccNum;
    private ResultSet rsAccNum;
    
    private PreparedStatement stAccType;
    private ResultSet rsAccType;
    
    private PreparedStatement stAccBalance;
    private ResultSet rsAccBalance;

    public AccountDetails() {
        initComponents();
        setExtendedState(AccountDetails.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        connectToDatabase();
        fetchPINPass();
        fetchName();
        fetchPhoneNumber();
        fetchGender();
        fetchAddress();
        fetchAccNumber();
        fetchAccType();
        fetchAccBalance();
        updateDate();
    }

    private void connectToDatabase(){
        try {
            String url = "jdbc:mysql://localhost:3306/bankingsystem";
            String username = "root";
            String password = "";
            connector = DriverManager.getConnection(url, username, password);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Address = new javax.swing.JTextField();
        Name = new javax.swing.JTextField();
        Num = new javax.swing.JTextField();
        Gender = new javax.swing.JTextField();
        Edit = new javax.swing.JToggleButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        AccType = new javax.swing.JTextField();
        AccBalance = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        AccNum = new javax.swing.JTextField();
        Hide = new javax.swing.JToggleButton();
        Pin = new javax.swing.JPasswordField();
        DeleteButton = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        LiveDate = new javax.swing.JTextField();
        Menu = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Account Details");
        setAlwaysOnTop(true);
        setAutoRequestFocus(false);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFocusable(false);
        setName("Account Details"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(34, 45, 101));
        jPanel1.setPreferredSize(new java.awt.Dimension(1366, 768));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(null);

        jPanel6.setBackground(new java.awt.Color(0, 0, 51));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(204, 204, 204), null, new java.awt.Color(204, 204, 204)));
        jPanel6.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Address");
        jPanel6.add(jLabel1);
        jLabel1.setBounds(20, 370, 120, 32);

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Personal Information");
        jPanel6.add(jLabel4);
        jLabel4.setBounds(90, 10, 370, 50);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Name");
        jPanel6.add(jLabel5);
        jLabel5.setBounds(20, 120, 110, 50);

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Phone Number");
        jPanel6.add(jLabel6);
        jLabel6.setBounds(20, 200, 210, 50);

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Gender");
        jPanel6.add(jLabel7);
        jLabel7.setBounds(20, 290, 110, 30);

        Address.setEditable(false);
        Address.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Address.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddressActionPerformed(evt);
            }
        });
        jPanel6.add(Address);
        Address.setBounds(280, 370, 250, 40);

        Name.setEditable(false);
        Name.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameActionPerformed(evt);
            }
        });
        jPanel6.add(Name);
        Name.setBounds(280, 130, 250, 40);

        Num.setEditable(false);
        Num.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Num.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Num.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumActionPerformed(evt);
            }
        });
        jPanel6.add(Num);
        Num.setBounds(280, 210, 250, 40);

        Gender.setEditable(false);
        Gender.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Gender.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Gender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenderActionPerformed(evt);
            }
        });
        jPanel6.add(Gender);
        Gender.setBounds(280, 290, 250, 40);

        Edit.setBackground(new java.awt.Color(51, 51, 51));
        Edit.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Edit.setForeground(new java.awt.Color(255, 255, 255));
        Edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit.png"))); // NOI18N
        Edit.setText("Edit");
        Edit.setBorderPainted(false);
        Edit.setFocusable(false);
        Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditActionPerformed(evt);
            }
        });
        jPanel6.add(Edit);
        Edit.setBounds(210, 440, 120, 27);

        jPanel2.add(jPanel6);
        jPanel6.setBounds(30, 30, 560, 490);

        jPanel8.setBackground(new java.awt.Color(0, 0, 51));
        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, new java.awt.Color(204, 204, 204), null, new java.awt.Color(204, 204, 204)));
        jPanel8.setLayout(null);

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Account PIN");
        jPanel8.add(jLabel8);
        jLabel8.setBounds(20, 370, 250, 32);

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Account Details");
        jPanel8.add(jLabel9);
        jLabel9.setBounds(140, 10, 263, 50);

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Account Type");
        jPanel8.add(jLabel11);
        jLabel11.setBounds(20, 200, 210, 50);

        jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        jLabel12.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Account Balance");
        jPanel8.add(jLabel12);
        jLabel12.setBounds(20, 290, 260, 30);

        AccType.setEditable(false);
        AccType.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        AccType.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        AccType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccTypeActionPerformed(evt);
            }
        });
        jPanel8.add(AccType);
        AccType.setBounds(280, 210, 250, 40);

        AccBalance.setEditable(false);
        AccBalance.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        AccBalance.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        AccBalance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccBalanceActionPerformed(evt);
            }
        });
        jPanel8.add(AccBalance);
        AccBalance.setBounds(280, 290, 250, 40);

        jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        jLabel13.setFont(new java.awt.Font("Verdana", 1, 25)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Account Number");
        jPanel8.add(jLabel13);
        jLabel13.setBounds(20, 120, 260, 50);

        AccNum.setEditable(false);
        AccNum.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        AccNum.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        AccNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccNumActionPerformed(evt);
            }
        });
        jPanel8.add(AccNum);
        AccNum.setBounds(280, 130, 250, 40);

        Hide.setBackground(new java.awt.Color(51, 51, 51));
        Hide.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Hide.setForeground(new java.awt.Color(255, 255, 255));
        Hide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/show.png"))); // NOI18N
        Hide.setFocusable(false);
        Hide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HideActionPerformed(evt);
            }
        });
        jPanel8.add(Hide);
        Hide.setBounds(380, 420, 70, 30);

        Pin.setEditable(false);
        Pin.setFont(new java.awt.Font("Verdana", 0, 20)); // NOI18N
        Pin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PinActionPerformed(evt);
            }
        });
        jPanel8.add(Pin);
        Pin.setBounds(280, 360, 250, 40);

        jPanel2.add(jPanel8);
        jPanel8.setBounds(600, 30, 560, 490);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(80, 100, 1190, 540);

        DeleteButton.setBackground(new java.awt.Color(255, 0, 0));
        DeleteButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        DeleteButton.setText("Delete Account");
        DeleteButton.setFocusable(false);
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });
        jPanel1.add(DeleteButton);
        DeleteButton.setBounds(1110, 650, 160, 27);

        jLabel16.setBackground(new java.awt.Color(0, 0, 0));
        jLabel16.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Unlock Your Account's Secrets");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(520, 50, 350, 50);

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/date.png"))); // NOI18N
        jLabel10.setText("Date :");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(900, 40, 110, 30);

        LiveDate.setEditable(false);
        LiveDate.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        LiveDate.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LiveDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LiveDateActionPerformed(evt);
            }
        });
        jPanel1.add(LiveDate);
        LiveDate.setBounds(1000, 40, 250, 30);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(80, 30, 120, 31);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(-10, -60, 1380, 1190);

        jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        jLabel14.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/date.png"))); // NOI18N
        jLabel14.setText("Date :");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(900, 40, 110, 30);

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/date.png"))); // NOI18N
        jLabel15.setText("Date :");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(900, 40, 110, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
       dispose();
    }//GEN-LAST:event_MenuActionPerformed
    
    private boolean isHidden = true;
    private void HideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HideActionPerformed
                                
   
        if (isHidden) {
        Pin.setEchoChar('\u0000');
        
        Hide.setIcon(new ImageIcon(getClass().getResource("/icons/hide.png")));
        isHidden = false;
    } else {
        Pin.setEchoChar('*');
       
        Hide.setIcon(new ImageIcon(getClass().getResource("/icons/show.png")));
        isHidden = true;
    }



    }//GEN-LAST:event_HideActionPerformed

    private void NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameActionPerformed
        fetchName();
    }//GEN-LAST:event_NameActionPerformed

    private void NumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumActionPerformed
       fetchPhoneNumber();
    }//GEN-LAST:event_NumActionPerformed

    private void GenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenderActionPerformed
        fetchGender();
    }//GEN-LAST:event_GenderActionPerformed

    private void AddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressActionPerformed
        fetchAddress();
    }//GEN-LAST:event_AddressActionPerformed

    private void AccNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccNumActionPerformed
        fetchAccNumber();
    }//GEN-LAST:event_AccNumActionPerformed

    private void AccTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccTypeActionPerformed
        fetchAccType();
    }//GEN-LAST:event_AccTypeActionPerformed

    private void AccBalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccBalanceActionPerformed
        fetchAccBalance();
    }//GEN-LAST:event_AccBalanceActionPerformed

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
        if(Edit.getText().equals("Edit")) {
        
        Num.setEditable(true);
        Gender.setEditable(true);
        Address.setEditable(true);
        
        Edit.setText("Save");
    } else if (Edit.getText().equals("Save")) {

        Login login = new Login();
        String accountNumber = Login.getUser();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");

            String newNum = Num.getText();
            String newGender = Gender.getText();
            String newAddress = Address.getText();

            PreparedStatement updatePstmt = conn.prepareStatement("UPDATE signup SET PhonNum=?, Gender=?, Address=? WHERE AccNum=?");
            updatePstmt.setString(1, newNum);
            updatePstmt.setString(2, newGender);
            updatePstmt.setString(3, newAddress);
            updatePstmt.setString(4, accountNumber);

            int rowsAffected = updatePstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Changes saved successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to change data.");
            }

            conn.close();

        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in editing. Please try again later.");
        }

        Num.setEditable(false);
        Gender.setEditable(false);
        Address.setEditable(false);

        Edit.setText("Edit");
    }
    }//GEN-LAST:event_EditActionPerformed

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
            DeleteAccount delete = new DeleteAccount();
            delete.setVisible(true);
            delete.setLocationRelativeTo(null);   
    }//GEN-LAST:event_DeleteButtonActionPerformed

    private void LiveDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LiveDateActionPerformed
        updateDate();
    }//GEN-LAST:event_LiveDateActionPerformed

    private void PinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PinActionPerformed
        
    }//GEN-LAST:event_PinActionPerformed
    
    private void updateDate() {
        LocalDate currentDate = LocalDate.now();
        String formattedDate = currentDate.toString();
        LiveDate.setText(formattedDate);
    }
    
    private void fetchName() {
        Login login = new Login();
        String accountNumber = Login.getUser();
        
    try {
        
        String query = "SELECT FirstName, LastName FROM signup WHERE AccNum = ?"; 
        stname = connector.prepareStatement(query);
        stname.setString(1, accountNumber);
        rs = stname.executeQuery();

        if (rs.next()) {
            String firstName = rs.getString("FirstName"); 
            String lastName = rs.getString("LastName"); 
            String fullName = firstName + " " + lastName; 
            Name.setText(fullName); 
            
        } else {
            Name.setText("No data found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching name: " + e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stname != null) {
                stname.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    private void fetchPhoneNumber() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT PhonNum FROM signup WHERE AccNum = ?"; 
        stPhone = connector.prepareStatement(query);
        stPhone.setString(1, accountNumber);
        rs = stPhone.executeQuery();

        if (rs.next()) {
            String phoneNumber = rs.getString("PhonNum"); 
            Num.setText(phoneNumber);
        } else {
            Num.setText("No phone number found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stPhone != null) {
                stPhone.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    private void fetchGender() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT Gender FROM signup WHERE AccNum = ?"; 
        stGender = connector.prepareStatement(query);
        stGender.setString(1, accountNumber);
        rsGender = stGender.executeQuery();

        if (rsGender.next()) {
            String gender = rsGender.getString("Gender");
            Gender.setText(gender);
        } else {
            Gender.setText("No Gender found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stGender != null) {
                stGender.close();
            }
            if (rsGender != null) {
                rsGender.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
    private void fetchAddress() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT Address FROM signup WHERE AccNum = ?";
        stAdd = connector.prepareStatement(query);
        stAdd.setString(1, accountNumber);
        rsAdd = stAdd.executeQuery();

        if (rsAdd.next()) {
            String address = rsAdd.getString("Address");
            Address.setText(address);
        } else {
            Address.setText("No Address found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching address: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stAdd != null) {
                stAdd.close();
            }
            if (rsAdd != null) {
                rsAdd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
    private void fetchAccNumber() {
    try {
        
        Login login = new Login();
        String accountNumber = Login.getUser();
        
        String query = "SELECT AccNum FROM signup WHERE AccNum = ?"; 
        stAccNum = connector.prepareStatement(query);
        stAccNum.setString(1, accountNumber);
        rsAccNum = stAccNum.executeQuery();
        

        if (rsAccNum.next()) {
            String Add = rsAccNum.getString("AccNum"); 
            AccNum.setText(Add);
        } else {
            AccNum.setText("No data found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching name: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stAccNum != null) {
                stAccNum.close();
            }
            if (rsAccNum != null) {
                rsAccNum.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    private void fetchAccType() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT Type FROM signup WHERE AccNum = ?";
        stAccType = connector.prepareStatement(query);
        stAccType.setString(1, accountNumber);
        rsAccType = stAccType.executeQuery();

        if (rsAccType.next()) {
            String accType = rsAccType.getString("Type"); 
            AccType.setText(accType); 
        } else {
            AccType.setText("No data found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching account type: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stAccType != null) {
                stAccType.close();
            }
            if (rsAccType != null) {
                rsAccType.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
    private void fetchAccBalance() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT Amount FROM signup WHERE AccNum = ?"; 
        stAccBalance = connector.prepareStatement(query);
        stAccBalance.setString(1, accountNumber);
        rsAccBalance = stAccBalance.executeQuery();

        if (rsAccBalance.next()) {
            int balance = rsAccBalance.getInt("Amount"); 
            AccBalance.setText(Integer.toString(balance)); 
        } else {
            AccBalance.setText("0");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching account balance: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (stAccBalance != null) {
                stAccBalance.close();
            }
            if (rsAccBalance != null) {
                rsAccBalance.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
            
    private void fetchPINPass() {
    try {
        Login login = new Login();
        String accountNumber = Login.getUser();

        String query = "SELECT PINPass FROM signup WHERE AccNum = ?";
        st = connector.prepareStatement(query);
        st.setString(1, accountNumber);
        rs = st.executeQuery();

        if (rs.next()) {
            int pinPass = rs.getInt("PINPass");
            String pinPassString = Integer.toString(pinPass);
            Pin.setText(pinPassString);
        } else {
            Pin.setText("No data found");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error fetching PINPass: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (st != null) {
                st.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error closing resources: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new AccountDetails().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AccBalance;
    private javax.swing.JTextField AccNum;
    private javax.swing.JTextField AccType;
    private javax.swing.JTextField Address;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JToggleButton Edit;
    private javax.swing.JTextField Gender;
    private javax.swing.JToggleButton Hide;
    private javax.swing.JTextField LiveDate;
    private javax.swing.JButton Menu;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Num;
    private javax.swing.JPasswordField Pin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    // End of variables declaration//GEN-END:variables
}
