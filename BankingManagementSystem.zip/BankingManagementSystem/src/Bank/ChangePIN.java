
package Bank;

import javax.swing.*;
import java.sql.*;

public class ChangePIN extends javax.swing.JFrame {

    public ChangePIN() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ChangeButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        EnterPINField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        SetNewPIN = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        ConfirmNewPIN = new javax.swing.JPasswordField();
        ShowButton = new javax.swing.JToggleButton();
        ErrorLabel4 = new javax.swing.JLabel();
        ErrorLabel5 = new javax.swing.JLabel();
        ErrorLabel6 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Menu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Change PIN");
        setAlwaysOnTop(true);
        setPreferredSize(new java.awt.Dimension(600, 535));
        setResizable(false);

        jPanel1.setLayout(null);

        ChangeButton.setBackground(new java.awt.Color(51, 51, 51));
        ChangeButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        ChangeButton.setForeground(new java.awt.Color(255, 255, 255));
        ChangeButton.setText("Change");
        ChangeButton.setFocusable(false);
        ChangeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangeButtonActionPerformed(evt);
            }
        });
        jPanel1.add(ChangeButton);
        ChangeButton.setBounds(230, 440, 110, 27);

        jPanel2.setBackground(new java.awt.Color(0, 0, 51));

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Enter Current PIN:");

        EnterPINField.setFont(new java.awt.Font("Verdana", 0, 21)); // NOI18N
        EnterPINField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        EnterPINField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                EnterPINFieldKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Set New PIN        :");

        SetNewPIN.setFont(new java.awt.Font("Verdana", 0, 21)); // NOI18N
        SetNewPIN.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        SetNewPIN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SetNewPINKeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 23)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Confirm New PIN  :");

        ConfirmNewPIN.setFont(new java.awt.Font("Verdana", 0, 21)); // NOI18N
        ConfirmNewPIN.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ConfirmNewPIN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ConfirmNewPINKeyPressed(evt);
            }
        });

        ShowButton.setBackground(new java.awt.Color(51, 51, 51));
        ShowButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/show.png"))); // NOI18N
        ShowButton.setFocusable(false);
        ShowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowButtonActionPerformed(evt);
            }
        });

        ErrorLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel4.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel5.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel6.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(EnterPINField)
                    .addComponent(ConfirmNewPIN, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
                    .addComponent(SetNewPIN)
                    .addComponent(ErrorLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ErrorLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ErrorLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ShowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(130, 130, 130))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EnterPINField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ErrorLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SetNewPIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ErrorLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(ErrorLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ConfirmNewPIN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ShowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(30, 140, 520, 280);

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Enhance Your Account Security");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(170, 110, 260, 30);

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 45)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Change PIN");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(150, 50, 310, 70);

        Menu.setBackground(new java.awt.Color(51, 51, 51));
        Menu.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Menu.setForeground(new java.awt.Color(255, 255, 255));
        Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        Menu.setText("Menu");
        Menu.setBorderPainted(false);
        Menu.setFocusPainted(false);
        Menu.setFocusable(false);
        Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuActionPerformed(evt);
            }
        });
        jPanel1.add(Menu);
        Menu.setBounds(40, 30, 110, 31);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/background.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(600, 600));
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 600, 770);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_MenuActionPerformed

    private boolean isHidden = true;
    private void ShowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowButtonActionPerformed
        if (isHidden) {
        SetNewPIN.setEchoChar((char) 0); 
        ConfirmNewPIN.setEchoChar((char) 0);
        isHidden = false;
        ShowButton.setIcon(new ImageIcon(getClass().getResource("/icons/hide.png")));
    } else {
        SetNewPIN.setEchoChar('*');
        ConfirmNewPIN.setEchoChar('*');
        isHidden = true;
        ShowButton.setIcon(new ImageIcon(getClass().getResource("/icons/show.png")));
    }
    }//GEN-LAST:event_ShowButtonActionPerformed

    private void ChangeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangeButtonActionPerformed
       
    String accountNumber = Login.getUser();
    String accountPIN = Login.getPass();

    String enteredPIN = EnterPINField.getText();

  

    if (enteredPIN.equals(accountPIN)) {
        String newPIN = SetNewPIN.getText();
        String confirmPIN = ConfirmNewPIN.getText();
        
        if (newPIN.equals(confirmPIN)) {
            int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to change your PIN?", "Confirm PIN Change", JOptionPane.YES_NO_OPTION);
            
            if (choice == JOptionPane.YES_OPTION) {
               
                updatePINInDatabase(accountNumber, newPIN);
                

                JOptionPane.showMessageDialog(this, "PIN changed successfully!");
                dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "The new PINs do not match. Please try again.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Incorrect PIN. Please try again.");
    }
}

    
    
private void updatePINInDatabase(String accountNumber, String newPIN) {
    Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");

        String sql = "UPDATE signup SET PINPass = ?, ConfirmPIN = ? WHERE Accnum = ?";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, newPIN);
        preparedStatement.setString(2, newPIN);
        preparedStatement.setString(3, accountNumber);

        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            
            System.out.println("PIN updated successfully.");
        } else {
           
            System.out.println("Failed to update PIN. Account number not found.");
        }
    } catch (SQLException e) {
             JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    } finally {
       
        try {
            if (preparedStatement != null) preparedStatement.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_ChangeButtonActionPerformed

    private void EnterPINFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_EnterPINFieldKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            EnterPINField.setEditable(false);
            ErrorLabel5.setText("Must be digits!");
        } else {
            EnterPINField.setEditable(true);
            ErrorLabel5.setText("");
        }
    }//GEN-LAST:event_EnterPINFieldKeyPressed

    private void SetNewPINKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SetNewPINKeyPressed
       char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            SetNewPIN.setEditable(false);
            ErrorLabel4.setText("Must be digits!");
        } else {
            SetNewPIN.setEditable(true);
            ErrorLabel4.setText("");
        }
    }//GEN-LAST:event_SetNewPINKeyPressed

    private void ConfirmNewPINKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ConfirmNewPINKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            ConfirmNewPIN.setEditable(false);
            ErrorLabel6.setText("Must be digits!");
        } else {
            ConfirmNewPIN.setEditable(true);
            ErrorLabel6.setText("");
        }
    }//GEN-LAST:event_ConfirmNewPINKeyPressed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> {
            new ChangePIN().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ChangeButton;
    private javax.swing.JPasswordField ConfirmNewPIN;
    private javax.swing.JTextField EnterPINField;
    private javax.swing.JLabel ErrorLabel4;
    private javax.swing.JLabel ErrorLabel5;
    private javax.swing.JLabel ErrorLabel6;
    private javax.swing.JButton Menu;
    private javax.swing.JPasswordField SetNewPIN;
    private javax.swing.JToggleButton ShowButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
