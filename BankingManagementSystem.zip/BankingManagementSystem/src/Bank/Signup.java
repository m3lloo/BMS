
package Bank;

import javax.swing.*;
import java.sql.*;
import java.util.Random;


public class Signup extends javax.swing.JFrame {

    public Signup() {
        initComponents();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        AllLabel = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        Hello = new javax.swing.JLabel();
        Hello2 = new javax.swing.JLabel();
        FirstNameLabel = new javax.swing.JLabel();
        FirstNameField = new javax.swing.JTextField();
        LastNameLabel = new javax.swing.JLabel();
        LastNameField = new javax.swing.JTextField();
        PhoneNumberLabel = new javax.swing.JLabel();
        PhonNumField = new javax.swing.JTextField();
        GenderLabel = new javax.swing.JLabel();
        AddressLabel = new javax.swing.JLabel();
        AddressField = new javax.swing.JTextField();
        AccTypeLabel = new javax.swing.JLabel();
        PinPass = new javax.swing.JTextField();
        PINLabel = new javax.swing.JLabel();
        ConfirmPINLabel = new javax.swing.JLabel();
        ConfirmPinPass = new javax.swing.JTextField();
        LoginButton = new javax.swing.JButton();
        HaveAnAccountLabel = new javax.swing.JLabel();
        SignupButton = new javax.swing.JButton();
        AccTypeBox = new javax.swing.JComboBox<>();
        GenderBox = new javax.swing.JComboBox<>();
        ErrorLabel = new javax.swing.JLabel();
        ErrorLabel2 = new javax.swing.JLabel();
        ErrorLabel3 = new javax.swing.JLabel();
        ErrorLabel4 = new javax.swing.JLabel();
        ErrorLabel5 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Signup");
        setAlwaysOnTop(true);
        setPreferredSize(new java.awt.Dimension(1000, 600));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel2.setToolTipText("");
        jPanel2.setName("Panel 1"); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(1100, 650));
        jPanel2.setLayout(null);

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setPreferredSize(new java.awt.Dimension(350, 650));

        AllLabel.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        AllLabel.setText("All rights reserved. 2024");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/namelogobms-removebg-preview (1).png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Verdana", 3, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("Banking that Empowers ");

        jLabel3.setFont(new java.awt.Font("Verdana", 3, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 204));
        jLabel3.setText("and  Tomorrow");

        jLabel5.setFont(new java.awt.Font("Verdana", 3, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 204));
        jLabel5.setText("Your today");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(AllLabel)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(27, 27, 27))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addComponent(jLabel3)))
                                .addGap(81, 81, 81))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel2)))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addComponent(AllLabel)
                .addGap(69, 69, 69))
        );

        jPanel2.add(jPanel3);
        jPanel3.setBounds(0, 0, 320, 600);

        jPanel4.setBackground(new java.awt.Color(0, 0, 51));

        Hello.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        Hello.setForeground(new java.awt.Color(255, 255, 255));
        Hello.setText("Hello! Please tell us a little bit ");

        Hello2.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        Hello2.setForeground(new java.awt.Color(255, 255, 255));
        Hello2.setText("about yourself.");

        FirstNameLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        FirstNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        FirstNameLabel.setText("First Name");

        FirstNameField.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        FirstNameField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        FirstNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstNameFieldActionPerformed(evt);
            }
        });
        FirstNameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                FirstNameFieldKeyPressed(evt);
            }
        });

        LastNameLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        LastNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        LastNameLabel.setText("Last Name");

        LastNameField.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        LastNameField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LastNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LastNameFieldActionPerformed(evt);
            }
        });
        LastNameField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LastNameFieldKeyPressed(evt);
            }
        });

        PhoneNumberLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        PhoneNumberLabel.setForeground(new java.awt.Color(255, 255, 255));
        PhoneNumberLabel.setText("Phone Number");

        PhonNumField.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        PhonNumField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PhonNumField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PhonNumFieldActionPerformed(evt);
            }
        });
        PhonNumField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PhonNumFieldKeyPressed(evt);
            }
        });

        GenderLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        GenderLabel.setForeground(new java.awt.Color(255, 255, 255));
        GenderLabel.setText("Gender(Male/Female)");

        AddressLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        AddressLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddressLabel.setText("Address");

        AddressField.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        AddressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddressFieldActionPerformed(evt);
            }
        });

        AccTypeLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        AccTypeLabel.setForeground(new java.awt.Color(255, 255, 255));
        AccTypeLabel.setText("Account Type");

        PinPass.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        PinPass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PinPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PinPassActionPerformed(evt);
            }
        });
        PinPass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PinPassKeyPressed(evt);
            }
        });

        PINLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        PINLabel.setForeground(new java.awt.Color(255, 255, 255));
        PINLabel.setText("PIN Password");

        ConfirmPINLabel.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ConfirmPINLabel.setForeground(new java.awt.Color(255, 255, 255));
        ConfirmPINLabel.setText("Confirm PIN Password");

        ConfirmPinPass.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        ConfirmPinPass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ConfirmPinPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmPinPassActionPerformed(evt);
            }
        });
        ConfirmPinPass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ConfirmPinPassKeyPressed(evt);
            }
        });

        LoginButton.setBackground(new java.awt.Color(0, 0, 0));
        LoginButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        LoginButton.setForeground(new java.awt.Color(255, 255, 255));
        LoginButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/login.png"))); // NOI18N
        LoginButton.setText("Login");
        LoginButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        LoginButton.setBorderPainted(false);
        LoginButton.setFocusPainted(false);
        LoginButton.setFocusable(false);
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        HaveAnAccountLabel.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        HaveAnAccountLabel.setForeground(new java.awt.Color(255, 255, 255));
        HaveAnAccountLabel.setText("Already have an account?");

        SignupButton.setBackground(new java.awt.Color(51, 51, 51));
        SignupButton.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        SignupButton.setForeground(new java.awt.Color(255, 255, 255));
        SignupButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/signup.png"))); // NOI18N
        SignupButton.setText("Signup");
        SignupButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        SignupButton.setFocusPainted(false);
        SignupButton.setFocusable(false);
        SignupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignupButtonActionPerformed(evt);
            }
        });

        AccTypeBox.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        AccTypeBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Savings Account", "Checking Account", "Health Savings Account", "Student Account", "Business Account" }));
        AccTypeBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccTypeBoxActionPerformed(evt);
            }
        });

        GenderBox.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        GenderBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        GenderBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenderBoxActionPerformed(evt);
            }
        });

        ErrorLabel.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel2.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel3.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel4.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        ErrorLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        ErrorLabel5.setForeground(new java.awt.Color(255, 255, 255));
        ErrorLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(HaveAnAccountLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LoginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(93, 93, 93))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AccTypeLabel)
                            .addComponent(Hello)
                            .addComponent(AddressField, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(ErrorLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                        .addComponent(FirstNameLabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ErrorLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(Hello2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 325, Short.MAX_VALUE)
                                    .addComponent(PhonNumField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FirstNameField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(AddressLabel, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PhoneNumberLabel, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(39, 39, 39)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(LastNameLabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ErrorLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(GenderLabel)
                                    .addComponent(LastNameField)
                                    .addComponent(GenderBox, 0, 276, Short.MAX_VALUE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(ErrorLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(AccTypeBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PINLabel, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PinPass, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE))
                                .addGap(57, 57, 57)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ConfirmPinPass, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE)
                                    .addComponent(ConfirmPINLabel)
                                    .addComponent(ErrorLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(297, 297, 297)
                        .addComponent(SignupButton, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Hello)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Hello2)
                .addGap(33, 33, 33)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(FirstNameLabel)
                        .addComponent(LastNameLabel))
                    .addComponent(ErrorLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ErrorLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FirstNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LastNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PhoneNumberLabel)
                    .addComponent(GenderLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PhonNumField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GenderBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ErrorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddressLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddressField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(AccTypeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AccTypeBox, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PINLabel)
                    .addComponent(ConfirmPINLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PinPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ConfirmPinPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(ErrorLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(SignupButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(HaveAnAccountLabel)
                            .addComponent(LoginButton)))
                    .addComponent(ErrorLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(92, 92, 92))
        );

        PhonNumField.getAccessibleContext().setAccessibleName("");

        jPanel2.add(jPanel4);
        jPanel4.setBounds(280, 0, 730, 600);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1014, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 77, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 67, Short.MAX_VALUE))
        );

        jPanel2.getAccessibleContext().setAccessibleName("Panel1");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FirstNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstNameFieldActionPerformed
        
    }//GEN-LAST:event_FirstNameFieldActionPerformed

    private void LastNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LastNameFieldActionPerformed
       
    }//GEN-LAST:event_LastNameFieldActionPerformed

    private void PhonNumFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PhonNumFieldActionPerformed
   
    }//GEN-LAST:event_PhonNumFieldActionPerformed

    

    private void AddressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressFieldActionPerformed
        
    }//GEN-LAST:event_AddressFieldActionPerformed

    private void PinPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PinPassActionPerformed
        
    }//GEN-LAST:event_PinPassActionPerformed

    private void ConfirmPinPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmPinPassActionPerformed
        
    }//GEN-LAST:event_ConfirmPinPassActionPerformed

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
      Login LoginFrame = new Login();  
      LoginFrame.setVisible(true);
      LoginFrame.pack();
      LoginFrame.setLocationRelativeTo(null);
      this.dispose();
    }//GEN-LAST:event_LoginButtonActionPerformed

    private void AccTypeBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccTypeBoxActionPerformed
        
    }//GEN-LAST:event_AccTypeBoxActionPerformed

    private void GenderBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenderBoxActionPerformed
        
    }//GEN-LAST:event_GenderBoxActionPerformed
    
  

    private String generateAccountNumber() {
        Random random = new Random();
        int randomNumber = random.nextInt(900000) + 100000; 
        return String.valueOf(randomNumber);
    }

    private void SignupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignupButtonActionPerformed
        String Amount = "0";  
        String Value = GenderBox.getSelectedItem().toString();
        String AccType = AccTypeBox.getSelectedItem().toString();
        String firstName = FirstNameField.getText().trim();
        
    if (firstName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "First name required.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String lastName = LastNameField.getText().trim();
    if (lastName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Last name required.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String address = AddressField.getText().trim();
    if (address.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Address required.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String phoneNumber = PhonNumField.getText().trim();
    if (phoneNumber.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Phone number required.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!phoneNumber.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "Your phone number must be in numeric format.\nPlease verify before submitting.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!phoneNumber.startsWith("09")) {
        JOptionPane.showMessageDialog(this, "The phone number field requires the number to start with '09'.\nKindly adhere to this requirement.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (phoneNumber.length() != 11) {
        JOptionPane.showMessageDialog(this, "The phone number field requires 11 digits.\nKindly adhere to this requirement.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }


    if (!phoneNumber.matches("\\d{11}")) {
        JOptionPane.showMessageDialog(this, "The phone number field requires a valid 11-digit number.\nKindly adhere to this requirement.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String pin = PinPass.getText().trim();
    if (pin.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Your PIN password is required for verification.\nPlease enter it.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!pin.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "Your PIN password should consist of numeric digits only.\nPlease input accordingly.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String confirmPin = ConfirmPinPass.getText().trim();
    if (confirmPin.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Your PIN password requires confirmation.\nPlease input it once more.", "Error", JOptionPane.ERROR_MESSAGE);
        return; 
    }

    if (!pin.equals(confirmPin)) {
        JOptionPane.showMessageDialog(this, "The PIN entered does not match the Confirm PIN.\nPlease check and try again.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");
        String sql = "INSERT INTO signup (AccNum, FirstName, LastName, PhonNum, Gender, Address, Amount, Type, PINPass, ConfirmPIN) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ptstmt = conn.prepareStatement(sql);
        String AccNum = generateAccountNumber();
        ptstmt.setString(1, AccNum);
        ptstmt.setString(2, firstName);
        ptstmt.setString(3, lastName);
        ptstmt.setString(4, phoneNumber);
        ptstmt.setString(5, Value);
        ptstmt.setString(6, address);
        ptstmt.setString(7, Amount);
        ptstmt.setString(8, AccType);
        ptstmt.setString(9, pin);
        ptstmt.setString(10, ConfirmPinPass.getText());
        
        int rowsAffected = ptstmt.executeUpdate();
        
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Signup Successfully\nYour Account Number:\n" + AccNum , "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            Login login = new Login();
            login.setVisible(true);
            login.setLocationRelativeTo(null);
        } else {
            JOptionPane.showMessageDialog(this, "Signup failed.\nPlease try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        conn.close();
    } catch (ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(this, "Please provide your information to sign up.", "Sign up Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_SignupButtonActionPerformed

    private void PhonNumFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PhonNumFieldKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            PhonNumField.setEditable(false);
            ErrorLabel.setText("Must be digits only!");
        } else {
            PhonNumField.setEditable(true);
            ErrorLabel.setText("");
        }
    }//GEN-LAST:event_PhonNumFieldKeyPressed

    private void PinPassKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PinPassKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            PinPass.setEditable(false);
            ErrorLabel2.setText("Must be digits only!");
        } else {
            PinPass.setEditable(true);
            ErrorLabel2.setText("");
        }
    }//GEN-LAST:event_PinPassKeyPressed

    private void ConfirmPinPassKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ConfirmPinPassKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            ConfirmPinPass.setEditable(false);
            ErrorLabel3.setText("Must be digits only!");
        } else {
            ConfirmPinPass.setEditable(true);
            ErrorLabel3.setText("");
        }
    }//GEN-LAST:event_ConfirmPinPassKeyPressed

    private void FirstNameFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FirstNameFieldKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isDigit(input)){
            FirstNameField.setEditable(false);
            ErrorLabel4.setText("Must be characters only!");
        } else {
            FirstNameField.setEditable(true);
            ErrorLabel4.setText("");
        }
    }//GEN-LAST:event_FirstNameFieldKeyPressed

    private void LastNameFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LastNameFieldKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isDigit(input)){
            LastNameField.setEditable(false);
            ErrorLabel5.setText("Must be characters only!");
        } else {
            LastNameField.setEditable(true);
            ErrorLabel5.setText("");
        }
    }//GEN-LAST:event_LastNameFieldKeyPressed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> {
            new Signup().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AccTypeBox;
    private javax.swing.JLabel AccTypeLabel;
    private javax.swing.JTextField AddressField;
    private javax.swing.JLabel AddressLabel;
    private javax.swing.JLabel AllLabel;
    private javax.swing.JLabel ConfirmPINLabel;
    private javax.swing.JTextField ConfirmPinPass;
    private javax.swing.JLabel ErrorLabel;
    private javax.swing.JLabel ErrorLabel2;
    private javax.swing.JLabel ErrorLabel3;
    private javax.swing.JLabel ErrorLabel4;
    private javax.swing.JLabel ErrorLabel5;
    private javax.swing.JTextField FirstNameField;
    private javax.swing.JLabel FirstNameLabel;
    private javax.swing.JComboBox<String> GenderBox;
    private javax.swing.JLabel GenderLabel;
    private javax.swing.JLabel HaveAnAccountLabel;
    private javax.swing.JLabel Hello;
    private javax.swing.JLabel Hello2;
    private javax.swing.JTextField LastNameField;
    private javax.swing.JLabel LastNameLabel;
    private javax.swing.JButton LoginButton;
    private javax.swing.JLabel PINLabel;
    private javax.swing.JTextField PhonNumField;
    private javax.swing.JLabel PhoneNumberLabel;
    private javax.swing.JTextField PinPass;
    private javax.swing.JButton SignupButton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables

   
}
