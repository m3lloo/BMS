
package Bank;

import java.awt.*;
import javax.swing.*;
import java.sql.*;

public class Login extends javax.swing.JFrame {

   private static String user;
   private static String pass;
    public Login() {
        initComponents();
        getUser();
    }
 
    public static String getPass() {
        return pass;
    }
 
    public static String getUser() {
        return user;
    }
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LoginPanel = new javax.swing.JPanel();
        Left = new javax.swing.JPanel();
        AllLabel = new javax.swing.JLabel();
        Banking = new javax.swing.JLabel();
        Management = new javax.swing.JLabel();
        System = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Right = new javax.swing.JPanel();
        LoginText = new javax.swing.JLabel();
        AccNumField = new javax.swing.JTextField();
        PasswordLabel = new javax.swing.JLabel();
        LoginButton = new javax.swing.JButton();
        PassField = new javax.swing.JPasswordField();
        DontHaveAnAccount = new javax.swing.JLabel();
        SignupButton = new javax.swing.JButton();
        AccountNumberLabel = new javax.swing.JLabel();
        Error = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFocusCycleRoot(false);
        setName("Login Frame"); // NOI18N
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        LoginPanel.setPreferredSize(new java.awt.Dimension(800, 500));
        LoginPanel.setLayout(null);

        Left.setBackground(new java.awt.Color(204, 204, 204));
        Left.setMinimumSize(new java.awt.Dimension(5000, 5000));
        Left.setPreferredSize(new java.awt.Dimension(400, 500));

        AllLabel.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        AllLabel.setText("All rights reserved. 2024");

        Banking.setFont(new java.awt.Font("Verdana", 1, 50)); // NOI18N
        Banking.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logbms-removebg-preview (1).png"))); // NOI18N

        Management.setFont(new java.awt.Font("Verdana", 1, 50)); // NOI18N
        Management.setText("Management");

        System.setFont(new java.awt.Font("Verdana", 1, 50)); // NOI18N
        System.setText("System");

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Current.");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("All Rights Reserved. 2024");

        javax.swing.GroupLayout LeftLayout = new javax.swing.GroupLayout(Left);
        Left.setLayout(LeftLayout);
        LeftLayout.setHorizontalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftLayout.createSequentialGroup()
                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(AllLabel))
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Management)
                            .addComponent(System)
                            .addComponent(Banking)))
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jLabel1))
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLabel2)))
                .addContainerGap(4618, Short.MAX_VALUE))
        );
        LeftLayout.setVerticalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LeftLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(Banking)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(46, 46, 46)
                .addComponent(jLabel2)
                .addGap(91, 91, 91)
                .addComponent(Management)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(System, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(AllLabel)
                .addGap(36, 36, 36))
        );

        LoginPanel.add(Left);
        Left.setBounds(0, 0, 400, 500);

        Right.setBackground(new java.awt.Color(0, 0, 51));
        Right.setMinimumSize(new java.awt.Dimension(400, 500));
        Right.setPreferredSize(new java.awt.Dimension(400, 500));

        LoginText.setBackground(new java.awt.Color(102, 153, 0));
        LoginText.setFont(new java.awt.Font("Verdana", 1, 55)); // NOI18N
        LoginText.setForeground(new java.awt.Color(255, 255, 255));
        LoginText.setText("Login");

        AccNumField.setFont(new java.awt.Font("Verdana", 0, 15)); // NOI18N
        AccNumField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        AccNumField.setToolTipText("");
        AccNumField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccNumFieldActionPerformed(evt);
            }
        });
        AccNumField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AccNumFieldKeyPressed(evt);
            }
        });

        PasswordLabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        PasswordLabel.setForeground(new java.awt.Color(255, 255, 255));
        PasswordLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/pincode.png"))); // NOI18N
        PasswordLabel.setText(" Password");

        LoginButton.setBackground(new java.awt.Color(51, 51, 51));
        LoginButton.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        LoginButton.setForeground(new java.awt.Color(255, 255, 255));
        LoginButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/login.png"))); // NOI18N
        LoginButton.setText("Login");
        LoginButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        LoginButton.setFocusable(false);
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        PassField.setFont(new java.awt.Font("Verdana", 0, 15)); // NOI18N
        PassField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PassField.setPreferredSize(new java.awt.Dimension(64, 24));
        PassField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PassFieldActionPerformed(evt);
            }
        });

        DontHaveAnAccount.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        DontHaveAnAccount.setForeground(new java.awt.Color(255, 255, 255));
        DontHaveAnAccount.setText("I don't have an account");

        SignupButton.setBackground(new java.awt.Color(0, 0, 51));
        SignupButton.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        SignupButton.setForeground(new java.awt.Color(255, 255, 255));
        SignupButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/signup.png"))); // NOI18N
        SignupButton.setText("Sign up");
        SignupButton.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        SignupButton.setBorderPainted(false);
        SignupButton.setFocusable(false);
        SignupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignupButtonActionPerformed(evt);
            }
        });

        AccountNumberLabel.setBackground(new java.awt.Color(255, 255, 255));
        AccountNumberLabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        AccountNumberLabel.setForeground(new java.awt.Color(255, 255, 255));
        AccountNumberLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/accountnumber.png"))); // NOI18N
        AccountNumberLabel.setText(" Account Number");

        Error.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        Error.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout RightLayout = new javax.swing.GroupLayout(Right);
        Right.setLayout(RightLayout);
        RightLayout.setHorizontalGroup(
            RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RightLayout.createSequentialGroup()
                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(PassField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(PasswordLabel, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AccNumField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AccountNumberLabel, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(RightLayout.createSequentialGroup()
                                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LoginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DontHaveAnAccount))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SignupButton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(LoginText))
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        RightLayout.setVerticalGroup(
            RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RightLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(LoginText)
                .addGap(55, 55, 55)
                .addComponent(AccountNumberLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AccNumField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Error, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(PasswordLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PassField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(LoginButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DontHaveAnAccount)
                    .addComponent(SignupButton))
                .addGap(28, 28, 28))
        );

        LoginPanel.add(Right);
        Right.setBounds(400, 0, 400, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LoginPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LoginPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AccNumFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccNumFieldActionPerformed
   
    }//GEN-LAST:event_AccNumFieldActionPerformed

    private void SignupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignupButtonActionPerformed
      Signup SignupFrame = new Signup();  
      SignupFrame.setVisible(true);
      SignupFrame.pack();
      SignupFrame.setLocationRelativeTo(null);
      this.dispose();
    }//GEN-LAST:event_SignupButtonActionPerformed

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        user = AccNumField.getText();
        pass = PassField.getText();

        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem", "root", "");
        String sql = "SELECT AccNum, PINPass FROM signup";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);

        boolean isAuthenticated = false; 

        while (rs.next()) {
            String AccNum = rs.getString("AccNum");
            String PINPass = rs.getString("PINPass");

                if (user.equals(AccNum) && pass.equals(PINPass)) {
                    isAuthenticated = true;
                    dispose();
                    break;
                }
        }

        if (isAuthenticated) {
            new Menu().setVisible(true);
            
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }

    } catch (HeadlessException | ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed.");
    }
    }//GEN-LAST:event_LoginButtonActionPerformed

    private void PassFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PassFieldActionPerformed
       
    }//GEN-LAST:event_PassFieldActionPerformed

    private void AccNumFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AccNumFieldKeyPressed
        char input = evt.getKeyChar();  
        if(Character.isLetter(input)){
            AccNumField.setEditable(false);
            Error.setText("Must be digits only!");
        } else {
            AccNumField.setEditable(true);
            Error.setText("");
        }
    }//GEN-LAST:event_AccNumFieldKeyPressed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AccNumField;
    private javax.swing.JLabel AccountNumberLabel;
    private javax.swing.JLabel AllLabel;
    private javax.swing.JLabel Banking;
    private javax.swing.JLabel DontHaveAnAccount;
    private javax.swing.JLabel Error;
    private javax.swing.JPanel Left;
    private javax.swing.JButton LoginButton;
    private javax.swing.JPanel LoginPanel;
    private javax.swing.JLabel LoginText;
    private javax.swing.JLabel Management;
    private javax.swing.JPasswordField PassField;
    private javax.swing.JLabel PasswordLabel;
    private javax.swing.JPanel Right;
    private javax.swing.JButton SignupButton;
    private javax.swing.JLabel System;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
    
}
